const express = require('express');

const router = express.Router();

const Product = require('../models/product')

const multer = require('multer');
filename ='';
const mystorge = multer.diskStorage({
    destination:'./uploads' ,
    filename:(req,file, redirect)=>{

       let date = Date.now();
       let f1 = date +'.'+file.mimetype.split('/')[1];
       redirect(null , f1);
       filename = f1 ;
       }
})

const upload = multer({storage: mystorge});





router.post('/createProduct' , upload.any('image'), async (req , res )=>{

    try{
        data = req.body;
        prod = new Product(data);
        prod.image = filename;
        savedprod = await prod.save();
        filename ='';
        res.status(200).send(savedprod);
    } catch (error){
        res.status(400).send(error)
    }
  })


router.get('/allProduct' , async (req , res )=>{
    try{
       
        prods = await Product.find( );
        res.status(200).send(prods);

        } catch (error){
            res.status(400).send(error)
        }
});

router.put('/updateProduct/:id',(req , res)=>{
    id = req.params.id;
     newData = req.body;
     Product.findOneAndUpdate({_id : id}, newData)
     .then(
        (updatedProduct)=>{    
            res.status(200).send(updatedProduct)
            }
            )
            .catch(
                (err)=>{
                    res.status(400).send(err)
                    }
                    )
                
    });
router.delete('/deleteProduct/:id',(req ,res)=>{
id =req.params.id;
Product.findOneAndDelete({_id : id})
.then(
    (deletedProduct)=>{
        res.send(deletedProduct)
        }
        )
        .catch(
            (err)=>{
                res.send(err)
                }
                )
 });

module.exports = router;
