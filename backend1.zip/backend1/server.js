const express = require('express');

const proudcutRoute = require('./routes/product');
const userRoute = require ('./routes/user');
require('./config/connect');

const app = express();
app.use(express.json());

app.use('/prduct' , proudcutRoute)
app.use('/user' , userRoute)

app.use('/getimage' , express.static('./uploads'))




app.listen( 3000 , ()=>{
 console.log('server wotrk !');

} );